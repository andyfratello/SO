#include <stdio.h>
#include <unistd.h>
#include <string.h>
#define MAX_SIZE 8 // constant tamany maxim de numero

int esNumero(char *str) { 
	if (str == NULL) return 0;
	if (*str == '-') ++str; // negatiu?
	for (int i = 0; str[i] != '\0'; i++) {
		if (!(str[i] >= '0' && str[i] <= '9') || (i >= MAX_SIZE)) return 0;
	}
	return 1;
}

int main(int argc, char *argv[]) {
	int i;
	char buf[80];
	for (i = 0; i < argc; i++) {
		if (esNumero(argv[i]) == 1) {
			sprintf(buf, "%s és un número\n", argv[i]); // %s perque char *argv es un string 
		} else {
			sprintf(buf, "%s no és un número\n", argv[i]);
		}
		write(1, buf, strlen(buf));
	}
	return 0;
}