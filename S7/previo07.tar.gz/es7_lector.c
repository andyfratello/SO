#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <sys/wait.h>

int main(){
	int numero;
	char buff[256];
	read(0, &numero, sizeof(int));
	
	sprintf(buff, "%d\n", numero);
	write(1, buff, strlen(buff));
}
