#include <error.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <fcntl.h>

int id = 0;

void
create_child ()
{
  char s[100];
  int pid;

  switch (pid = fork ())
    {
    case -1:
      error (1, errno, "fork");

    case 0:
      sprintf (s, "%d", id);
      execl ("hijo2", "hijo2", s, NULL);
      error (1, errno, "execl");
    }
  sprintf (s, "SpawnF[pid=%5d] creates child id=%02d pid=%5d\n", getpid (),
           id, pid);
  if (write (2, s, strlen (s)) < 0)
    error (1, errno, "write");

  id++;
}

void
Usage ()
{
  error (1, 0, "Invalid argument.\nCorrect usage: spawnF N");
}

int
main (int argc, char *argv[])
{
  int N, i;
  char s[80];
  int fd_rw, fd_r;

  if (argc != 2)
    Usage ();

  N = atoi (argv[1]);

  sprintf (s, "SpawnF[pid=%5d] created, N=%d\n", getpid (), N);
  if (write (2, s, strlen (s)) < 0)
    error (1, errno, "write");

  fd_rw = open ("NP", O_RDWR);
  fd_r = open ("NP", O_RDONLY);
  if ((fd_rw < 0) || (fd_r < 0))
    error (1, errno, "open NP");
  if (dup2 (fd_r, 0) < 0)
    error (1, errno, "dup");

  for (i = 0; i < N; i++)
    create_child ();

  while (1)
    {
      int pid;

      if ((pid = wait (NULL)) < 0)
        error (1, errno, "waitpid");
      sprintf (s, "SpawnF[pid=%5d] child pid=%5d dye\n", getpid (), pid);
      if (write (2, s, strlen (s)) < 0)
        error (1, errno, "write");

      create_child ();
    }
}
