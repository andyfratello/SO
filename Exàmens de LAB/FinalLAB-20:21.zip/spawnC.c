#include <error.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <signal.h>

int id = 0, N;
int *pids;

void
pids_init ()
{
  pids = malloc (N * sizeof (int));
  if (pids == NULL)
    error (1, errno, "Out of memory");
  memset (pids, 0, N * sizeof (int));   // Inits to 0 all entries
}

void
pids_save (int pid)
{
  int i;

  for (i = 0; i < N; i++)
    if (pids[i] == 0)
      {
        pids[i] = pid;
        return;
      }
  error (1, 0, "unexpected error");
}

void
pids_delete (int pid)
{
  int i;

  for (i = 0; i < N; i++)
    if (pids[i] == pid)
      {
        pids[i] = 0;
        return;
      }
  error (1, 0, "unexpected error");
}

void
sigusr1 (int signo)
{
  int i;

  for (i = 0; i < N; i++)
    {
      char s[80];

      sprintf (s, "SpawnC[pid=%5d] child at entry %d = %d\n", getpid (), i,
               pids[i]);
      if (write (1, s, strlen (s)) < 0)
        error (1, errno, "write");
    }
}

void
create_child ()
{
  char s[100];
  int pid;

  switch (pid = fork ())
    {
    case -1:
      error (1, errno, "fork");

    case 0:
      sprintf (s, "%d", id);
      execl ("hijo1", "hijo1", s, NULL);
      error (1, errno, "execl");
    }
  sprintf (s, "SpawnC[pid=%5d] creates child id=%02d pid=%5d\n", getpid (),
           id, pid);
  if (write (2, s, strlen (s)) < 0)
    error (1, errno, "write");

  pids_save (pid);

  id++;
}

void
Usage ()
{
  error (1, 0, "Invalid argument.\nCorrect usage: spawnC N");
}

int
main (int argc, char *argv[])
{
  int i;
  char s[80];
  struct sigaction new;

  if (argc != 2)
    Usage ();

  N = atoi (argv[1]);
  pids_init ();

  new.sa_handler = sigusr1;
  new.sa_flags = SA_RESTART;
  sigemptyset (&new.sa_mask);
  if (sigaction (SIGUSR1, &new, NULL) < 0)
    error (1, errno, "sigaction");

  sprintf (s, "SpawnC[pid=%5d] created, N=%d\n", getpid (), N);
  if (write (2, s, strlen (s)) < 0)
    error (1, errno, "write");

  for (i = 0; i < N; i++)
    create_child ();

  while (1)
    {
      int pid;

      if ((pid = wait (NULL)) < 0)
        error (1, errno, "waitpid");

      sprintf (s, "SpawnC[pid=%5d] child pid=%5d dye\n", getpid (), pid);
      if (write (2, s, strlen (s)) < 0)
        error (1, errno, "write");

      pids_delete (pid);

      create_child ();
    }
}
