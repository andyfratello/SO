#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>
#include <signal.h>

void halt(char c[]) {
	perror(c);
	exit(0);
}

void Usage() {
    char buffer[128];
    sprintf(buffer, "Usage: ./invirtiendo_fichero\n");
    write(1, buffer, strlen(buffer));
    exit(EXIT_FAILURE);
}

int main(int argc, char *argv[]) {
	if (argc < 2) Usage();
	else {
		int fd1, fd2, ini;
		char buff[256];
		if ((fd1 = open(argv[1], O_RDONLY)) < 0) halt("open");
		if (lseek(fd1, 0, SEEK_END) < 0) halt("lseek");
		if ((fd2 = creat("out", 0600)) < 0) halt("creat");
		char c;
		lseek(fd1, -1, SEEK_END);
		ini = -2;
		int b = 0;
		while (!b && read(fd1, &c, sizeof(char) > 0)) {
			write(fd2, &c, sizeof(char));
			if (lseek(fd1, ini, SEEK_END) < 0) b = 1;
			--ini;
		}
	}
}