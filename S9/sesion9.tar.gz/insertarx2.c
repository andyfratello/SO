#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>
#include <signal.h>

void error_y_exit(char* c) {
	perror(c);
	exit(0);
}

void Usage() {
    char buffer[128];
    sprintf(buffer, "Usage: ./insertarx2\n");
    write(1, buffer, strlen(buffer));
    exit(EXIT_FAILURE);
}

int main(int argc, char *argv[]) {
	if (argc < 2) Usage();
	else {
		char buff[256];
		char buffX[256];
		int f1 = open(argv[1], O_RDWR);
		int f2 = lseek(f1, 0, SEEK_END);
		if (f1 == -1) error_y_exit("Error. Ha fallat open");
		sprintf(buffX, "X");
		int x = atoi(argv[2]);
		while (x != f2) {
			lseek(f1, x, SEEK_SET);
			write(1,buffX,strlen(buffX));
			++x;
		}
		close(f1);
	}
}