#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>
#include <signal.h>

void halt(char c[]) {
	perror(c);
	exit(0);
}

void Usage() {
    char buffer[128];
    sprintf(buffer, "Usage: ./append\n");
    write(1, buffer, strlen(buffer));
    exit(EXIT_FAILURE);
}

int main(int argc, char *argv[]) {
	if (argc < 2) Usage();
	else {
		int fd;
		int ini;
		int fi;
		char buff[256];
		if ((fd = open(argv[1], O_RDWR)) < 0) halt("open");
		ini = 0;
		if ((fi = lseek(fd, 0, SEEK_END)) < 0) halt("lseek");
		char c;
		lseek(fd, ini, SEEK_SET);
		while ((read(fd, &c, sizeof(char) > 0) && ini < fi)) {
			lseek(fd, 0, SEEK_END);
			write(fd, &c, sizeof(char));
			++ini;
			lseek(fd, ini, SEEK_SET);
		}
	}
}